# Projectile-Motion
Basic projectile motion simulator based off Ontario grade 11/12 physics curriculum. (ICS4U1 Midterm Project)

https://github.com/henryinqz/Projectile-Motion/

## Instructions
1. Download 'ProjMotion.zip'
2. Unzip the file
3. Ensure you have Java Runtime installed (https://java.com/en/download/)
4. Execute 'ProjMotion.jar'

## Author
- Henry Wong
